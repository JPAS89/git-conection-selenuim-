package conexionbd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.Test;

public class Basedatos {

   @Test
   public void conexion() throws ClassNotFoundException, SQLException {
	
		String dbUrl = "jdbc:mysql://localhost:3306/db";
		String username ="root";
		String password ="root";
		String query = "select * from empleados;";
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection(dbUrl,username,password);
		Statement stmt = con.createStatement();
		ResultSet rs= stmt.executeQuery(query);

		while (rs.next()){
		 String myId= rs.getString(1);
		 String myName = rs.getString(2);
		 String myAge = rs.getString(3);
		 System. out.println(myId+" "+myName+" "+myAge);
		}
		con.close();
	}

}
